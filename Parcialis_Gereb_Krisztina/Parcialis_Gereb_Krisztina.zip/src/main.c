#include <stdio.h>
#include <orszag.h>


int main() {
    Country_t country1={"Nemetorszag", 23000, IGEN};
    printCountryDetails(country1);
    Country_t country2;
    readCountryDetails(&country2);
    printCountryDetails(country2);

    if(country1.area>country2.area) {
        printf(country1.name);
    } else
        printf(country2.name);

    return 0;
}
