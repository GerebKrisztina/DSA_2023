//
// Created by gereb on 3/28/2023.
//

#include "../headers/orszag.h"
#include "constants.h"

char* getTypeDescription(enum Type type) {
    switch (type) {
        case IGEN:
            return "IGEN";
        case NEM:
            return "NEM";
        default: return "UNDEFINED";
    }
}

void readCountryDetails(Country_t *pCountry) {
    scanf("%[^\n]\n", pCountry->name);
    scanf("%i\n", &pCountry->area);
    scanf("%i\n", &pCountry->type);
}

void printCountryDetails(Country_t country){
    printf("Nev: %s", country.name);
    printf("\tTerulete: %i", country.area);
    printf("\tEuropai-e: %i", country.type);
}
/*
void createArray(int capacity, CountryArray *pArray){

}
void printArray(CointryArray array){

}
bool isFull(CointryArray array){

}
bool isEmpty(CointryArray array){

}
int getItemAt(CointryArray array, int position){

}
void insertFirst(CountryArray *pArray CountryArray item){

}
void insertLast(CountryArray *pArray CountryArray item){

}
int search(CountryArray *pArray CountryArray item){

}
bool update(CountryArray* pArray, int position, CountryArray newItem){

}
void deallocateArray(CountryArray *pArray){

}*/
