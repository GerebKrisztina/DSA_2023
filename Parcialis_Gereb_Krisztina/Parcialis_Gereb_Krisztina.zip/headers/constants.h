//
// Created by gereb on 2/21/2023.
//

#ifndef LABOR2_CONSTANTS_H
#define LABOR2_CONSTANTS_H

static const int MEMORY_ALLOCATION_ERROR_CODE=-1;
static const char MEMORY_ALLOCATION_ERROR_MESSAGE[]="Memory allocation error";

static const int FILE_OPEN_ERROR_CODE=-2;
static const char FILE_OPEN_MESSAGE[]="File open error";

#endif //LABOR2_CONSTANTS_H
